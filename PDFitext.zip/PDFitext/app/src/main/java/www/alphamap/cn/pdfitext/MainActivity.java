package www.alphamap.cn.pdfitext;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends Activity {

    private TextView tv_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_content = (TextView)findViewById(R.id.tv_content);
    }

    //写入
    public void button_write(View view){
        writePdfContent(Environment.getExternalStorageDirectory() + "/test/test.pdf","这是一段测试数据！");
    }

    //查看
    public void button_read(View view){
        String content = readPdfContent(Environment.getExternalStorageDirectory() + "/test/test.pdf");
        tv_content.setText(content);
    }

    /**
     * 写入PDF内容
     */
    public void writePdfContent(final String path, final String content){
        //因为是耗时操作所以要在子线程中进行
        new Thread(){
            @Override
            public void run() {
                super.run();
                Document doc = new Document();//创建一个document对象
                FileOutputStream fos;
                try {
                    fos = new FileOutputStream(new File(path)); //pdf_address为Pdf文件保存到sd卡的路径
                    PdfWriter.getInstance(doc, fos);
                    doc.open();
                    doc.setPageCount(1);
                    doc.add(new Paragraph(content, setChineseFont())); //result为保存的字符串 ,setChineseFont()为pdf字体
                    // 一定要记得关闭document对象
                    doc.close();
                    fos.flush();
                    fos.close();
                    handler.sendEmptyMessage(123);//操作完毕后进行提醒
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (DocumentException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();

    }

    /**
     * 设置PDF字体(较为耗时)
     */
    public Font setChineseFont() {
        BaseFont bf = null;
        Font fontChinese = null;
        try {
            // STSong-Light : Adobe的字体
            // UniGB-UCS2-H : pdf 字体
            bf = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H",
                    BaseFont.NOT_EMBEDDED);
            fontChinese = new Font(bf, 12, Font.NORMAL);
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fontChinese;
    }

    /**
     * 读取Pdf文件的内容
     * @param path :文件地址
     */
    public String readPdfContent(String path){
        String content = "";
        File file = new File(path);
        if (file.exists()){
            try {
                PdfReader pr = new PdfReader(path);
                int page = pr.getNumberOfPages();
                for(int i = 1 ;i<page+1;i++){
                    //遍历页码,读取Pdf文件内容
                    content += PdfTextExtractor.getTextFromPage(pr, i);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(MainActivity.this,"文件不存在！",Toast.LENGTH_SHORT).show();
        }
        return content;

    }

    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 123:
                    Toast.makeText(MainActivity.this,"生成完毕，点击查看按钮查看文件内容！",Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };
}
