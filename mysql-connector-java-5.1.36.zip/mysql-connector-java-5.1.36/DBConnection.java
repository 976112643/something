package com.cnsunrun.test;

import java.sql.Connection;//java包
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static String dbDriver = "com.mysql.jdbc.Driver";
    private static String dbUrl = "jdbc:mysql://192.168.1.170:3306/wq";//根据实际情况变化
    private static String dbUser = "root";
    private static String dbPass = "";

    public static Connection getConn() {
        Connection conn = null;
        try {
            Class.forName(dbDriver);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);//注意是三个参数
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}